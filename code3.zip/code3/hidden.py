# Keep this file separate

# https://apps.twitter.com/
# Create new App and get the four strings

#def oauth():
    #return {"consumer_key": "h7Lu...Ng",
           # "consumer_secret": "dNKenAC3New...mmn7Q",
            #"token_key": "10185562-eibxCp9n2...P4GEQQOSGI",
            #"token_secret": "H0ycCFemmC4wyf1...qoIpBo"}
def oauth():
    return {"consumer_key": "tDOahhjApF7X05aIfrmlwLEHc",
            "consumer_secret": "ITww8cDJO2xvYgUsfqRuoxNzcmEco2lOMlF7cXZhKS7JLQwIeZ",
            "token_key": "1048314513668411393-oDoZo30MTZvWiQyJMTZrxk780MOCmZ",
            "token_secret": "tFH9Hiu1DkyS27mD9Ahkq9w30fHhfn4WFHPFK3Ew9gm0K"}