# 1. import library
import ssl
from urllib.request import urlopen
import sqlite3
import twurl
import json
# 2.ignore ssl certification
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
# 3.connecting with database and create a table
conn = sqlite3.connect('spider.sqlite')
cur = conn.cursor()
cur.execute('CREATE TABLE IF NOT EXISTS Twitter(name TEXT, retrieved INTEGER, friends INTEGER)')
# 4. start to load data from url
# url
TWITTER_URL = 'https://api.twitter.com/1.1/friends/list.json'
# prompt for a Twitter account
while True:
    acct = input('Enter a Twitter account, or quit: ')
    if (acct == 'quit'): break
    if (len(acct) < 1):
        cur.execute('SELECT name from Twitter WHERE retrieved = 0 LIMIT 1')
        try:
            acct = cur.fetchone()[0]
        except:
            print('No unretrieved Twitter accounts found')
            continue
# 5.start to make a url
    url = twurl.augment(TWITTER_URL, {'screen_name':acct, 'count': '5'})
    print('Retrieving', url)
# 6.connect to the url and load data
    connection = urlopen(url, context = ctx)
    data = connection.read().decode()
# 7. display the remaining use time of the API
    headers = dict(connection.getheaders())
    print('Remaining', headers['x-rate-limit-remaining'])
# 8.obtain js to further exploit the data
    js = json.loads(data)
    print(json.dumps(js, indent=4))
    cur.execute('UPDATE Twitter SET retrieved = 1 WHERE name = ?', (acct, ))
    countnew = 0
    countold = 0
    for u in js['users']:
        friend = u['screen_name']
        print(friend)
        cur.execute('SELECT friends FROM Twitter WHERE name = ? LIMIT 1', (friend, ))
# 9.the
        try:
            count = cur.fetchone()[0]
            print('look at here', count)
            cur.execute('UPDATE Twitter SET friends = ? WHERE name = ?'\
            ,(count + 1, friend))
            countfold = countfold + 1
        except:
            cur.execute('INSERT INTO Twitter (name, retrieved, VALUES(?, 0, 1)', (friends,))
            countnew = countnew + 1
            print('New accounts =', countnew, 'revisited', countold)
            conn.commit()
cur.close()

